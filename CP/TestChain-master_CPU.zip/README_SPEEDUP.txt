Readme Projeto 02 - Blockchain
A dificuldade 6 n�o foi testada, pois o servidor durante o final da entrega congestionou, com programas at� 400% de CPU.
Logo, executamos os testes para as dificuldades apresentadas abaixo:

Execu��o do c�digo sequencial (com dificuldade 5):
real    1m27.733s
user    1m27.708s

Execu��o do c�digo paralelo (com dificuldade 5):
real    0m47.684s
user    1m25.985s

Speedup: 2,678739199731566

Execu��o do c�digo sequencial (com dificuldade 4):
real    0m6.203s
user    0m6.200s

Execu��o do c�digo paralelo (com dificuldade 4):
real    0m2.393s
user    0m4.788s

Speedup: 2,592143752611784

Para vers�o GPU tivemos problemas em verificar o vetor de char da sHash(numeros de 0 para verificar com a dificuldade),
portanto n�o conseguimos implementar. Gostaria que verificasse o Block.cpp da pasta TestChain-master_GPU, para explicar o que 
que n�s n�o conseguimos implementar.


Integrantes:
Gabriel Campos
Luigi Soares
Vitor Fran�a
